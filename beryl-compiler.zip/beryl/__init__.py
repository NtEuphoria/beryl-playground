"""beryl's bounded correctness prototype."""
